abstract class Patisserie {
    public abstract String getName();
    public abstract double baseCost();
    public abstract double cost();
}